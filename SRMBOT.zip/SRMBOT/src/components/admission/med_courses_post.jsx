import React from "react";

// import "./AdmissionIndia.css";

const med_courses_post = (props) => {
  const med_courses_post = [
    {
      text: "SRM Medical College Hospital and Research Centre ",
      handler: props.actionProvider.med_courses_post1,
      id: 1,
    },
    {
      text: "SRM Kattankulathur Dental College and Hospital",
      handler: props.actionProvider.med_courses_post2,
      id: 2,
    },
    {
      text: "SRM Ramapuram Dental College ",
      handler: props.actionProvider.med_courses_post3,
      id: 3,
    },
    {
      text: "Health Sciences ",
      handler: props.actionProvider.med_courses_post4,
      id: 4,
    },
    
    {
      text: "Other courses Offered ",
      handler: props.actionProvider.med_courses_post5,
      id: 5,
    },
    
    
    
  ];

  const buttonsMarkup = med_courses_post.map((admin) => (
    <button key={admin.id} onClick={admin.handler} className="option-button">
      {admin.text}
    </button>
  ));

  return <div className="options-container">{buttonsMarkup}</div>;
};

export default med_courses_post;